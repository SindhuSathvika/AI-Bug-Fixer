from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import ast
import json
import subprocess

app = FastAPI()

class CodeInput(BaseModel):
    code: str

# --- Syntax Error Detection --- #
def analyze_syntax(code):
    try:
        ast.parse(code)  # Check if code is valid Python
        return {"status": "Valid Syntax", "errors": []}
    except SyntaxError as e:
        return {
            "status": "Syntax Error",
            "errors": [{"line": e.lineno, "message": e.msg}]
        }

# --- Inefficiency Detection (Nested Loops, Unused Variables) --- #
def detect_inefficiencies(code):
    inefficiencies = []
    tree = ast.parse(code)

    for node in ast.walk(tree):
        if isinstance(node, ast.For):
            for child in ast.walk(node):
                if isinstance(child, ast.For):  
                    inefficiencies.append({
                        "line": node.lineno,
                        "message": "Nested loops detected (O(n²)). Consider optimizing."
                    })
        if isinstance(node, ast.Assign) and not isinstance(node.ctx, ast.Store):
            inefficiencies.append({
                "line": node.lineno,
                "message": "Unused variable detected."
            })

    return inefficiencies

# --- CodeQL Security Analysis --- #
def run_codeql_scan():
    # Run CodeQL to analyze security vulnerabilities in code
    cmd = "./codeql/bin/codeql database analyze my_db python-security-and-quality.qls --format=sarif-latest --output=results.sarif"
    subprocess.run(cmd, shell=True)

    # Parse the results from CodeQL
    with open("results.sarif", "r") as file:
        results = json.load(file)
    
    vulnerabilities = []
    for result in results.get("runs", [])[0].get("results", []):
        vulnerabilities.append({
            "line": result["locations"][0]["physicalLocation"]["region"]["startLine"],
            "message": result["message"]["text"]
        })
    
    return vulnerabilities

@app.post("/analyze")
def analyze_code(input_data: CodeInput):
    # Syntax Check
    syntax_result = analyze_syntax(input_data.code)
    
    # Inefficiency Check (Nested Loops, Unused Variables)
    inefficiencies = detect_inefficiencies(input_data.code)
    
    # Run CodeQL for security vulnerabilities
    vulnerabilities = run_codeql_scan()

    # Return a comprehensive result
    return {
        "syntax": syntax_result,
        "inefficiencies": inefficiencies,
        "vulnerabilities": vulnerabilities
    }

